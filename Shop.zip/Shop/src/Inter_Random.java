public interface Inter_Random {
    public void StartLottery();
}
