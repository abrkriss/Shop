import java.util.ArrayList;
import java.util.Objects;

public interface Interf_Add_Toy {
    void addToy(Toy toy); // метод для добавления новых игрушек в магазин
}
