
public interface Inter_ChangeChance {
    public void ChangeChance(double val); // метод для изменения вероятности выпадения игрушек
}
